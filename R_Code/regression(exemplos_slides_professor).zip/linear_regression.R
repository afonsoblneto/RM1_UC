# Load data file
lsCaminho = "D:/GoogleDrive/afonsoblneto/Academia/Doutorado/COIMBRA/Disciplinas/M�todos de Investiga��o 1/Aulas/materiais_MI1_2019_2020_30-11-2019/regression"

#######  Example of a nonlinear model with Exponential model
lsFile = paste(lsCaminho, "regr1.in" , sep = "/")
D = read.table(lsFile,header=TRUE)

# linear regression without transformation
lr.out = lm(D$number~D$year)
summary(lr.out)
plot(D$number~D$year)
abline(lr.out)
# Use plot function this way and navigate through some graphics (press enter)
#plot(lr.out)


# linear regression with transformation
numTransf <- log(D$number)
D <- cbind(D, numTransf)
lr.out = lm(numTransf~D$year)
plot(D$numTransf~D$year)
summary(lr.out)
abline(lr.out)
# Use plot function this way and navigate through some graphics (press enter)
#plot(lr.out)


#######  Example of a nonlinear model with Reciprocal model
lsFile = paste(lsCaminho, "regr3.in" , sep = "/")
D = read.table(lsFile,header=TRUE)

# linear regression without transformation
lr.out = lm(D$time~D$processors)
summary(lr.out)
plot(D$time~D$processors)
abline(lr.out)
# Use plot function this way and navigate through some graphics (press enter)
#plot(lr.out)

# linear regression with transformation
numTransf <- (1/D$time)
D <- cbind(D, numTransf)
lr.out = lm(numTransf~D$processors)
plot(D$numTransf~D$processors)
summary(lr.out)
abline(lr.out)
# Use plot function this way and navigate through some graphics (press enter)
#plot(lr.out)


#######  Example of a nonlinear model with Quadratic model
lsFile = paste(lsCaminho, "regr2.in" , sep = "/")
D = read.table(lsFile,header=TRUE)

# linear regression without transformation
lr.out = lm(D$time~D$size)
summary(lr.out)
plot(D$time~D$size)
abline(lr.out)
# Use plot function this way and navigate through some graphics (press enter)
#plot(lr.out)

# linear regression with transformation
numTransf <- sqrt(D$number)
D <- cbind(D, numTransf)
lr.out = lm(numTransf~D$size)
plot(D$numTransf~D$size)
summary(lr.out)
abline(lr.out)
# Use plot function this way and navigate through some graphics (press enter)
#plot(lr.out)

#######  Example of a nonlinear model with Logarithm model
lsFile = paste(lsCaminho, "regr4.in" , sep = "/")
D = read.table(lsFile,header=TRUE)

# linear regression without transformation
lr.out = lm(D$time~D$size)
summary(lr.out)
plot(D$time~D$size)
abline(lr.out)
# Use plot function this way and navigate through some graphics (press enter)
#plot(lr.out)

# linear regression with transformation
numTransf <- log(D$size)
D <- cbind(D, numTransf)
lr.out = lm(D$time~numTransf)
plot(D$time~numTransf)
summary(lr.out)
abline(lr.out)
# Use plot function this way and navigate through some graphics (press enter)
#plot(lr.out)

